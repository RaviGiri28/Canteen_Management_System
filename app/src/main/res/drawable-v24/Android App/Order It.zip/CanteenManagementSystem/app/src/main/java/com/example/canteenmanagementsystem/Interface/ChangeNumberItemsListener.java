package com.example.canteenmanagementsystem.Interface;

public interface ChangeNumberItemsListener {
    void changed();
}
